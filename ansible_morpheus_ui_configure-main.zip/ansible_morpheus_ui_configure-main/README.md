# Configuring Morpheus Appliance UI
---

Use this at your own risk. I make no guarantees that this will work for whatever environment you are deploying this into.

# The Purpose
---
Perform configurations and set up of a Morpheus Enterprise or VM Essentials manager


# Requirements
---

1. A host with ansible installed from which to run the playbooks
2. Network connectivity to the appliances you wish to configure
3. Credentials for the Morpheus appliance to be set up with
4. Live integration point which will be used for the setup

# Usage

### Preparing
---

1. You will want to update the morph_01.yml playbook and then create a new playbook for each additional appliance you want to configure in the playbooks directory. Look to the *playbooks->examples* directory to see some usage types.
2. Update the morph_01.yml vars file under *inventory->host_vars->morph_01.yml* with your variables.
3. Add your hosts to the inventory file at *inventory->hosts.ini*

### Deploying
---

Once you are ready to run the configuration, simply run the following command from the root of this repo. You can run it multiple times and each integration/group/image/etc... will only be created if it does not already exist. 

```
ansible-playbook morph_01.yml --ask-become-pass
```


## ROLES

There are multiple roles which you can utilize for setting up your appliance. This is not exhaustive, nor will it ever be. If I didn't put it in here, it's because I didn't have a need to and I am not going to just because YOU might want it. Feel free to add your own roles if you need them.

### Available Roles
---

| Role | Purpose | Depends On |
|---|---|---|
| [common](#gear-common) | Holds tasks which will be used regardless of environment | None |
| [initial_setup](#gear-initial_setup) | Performs the initial setup of the appliance | None |
| [create_cloud_morpheus](#gear-create_cloud_morpheus) | Creates a Morpheus type cloud | common, create_groups | 
| [create_cloud_vcenter](#gear-create_cloud_vcenter) | Creates a vCenter type cloud | common, initial_setup |
| [create_groups](#gear-create_groups) | Creates infrastructure groups from a list of group names | common, initial_setup |
| [create_idp_ad](#gear-create_idp_ad) | Creates an Active Directory identity provider | common, initial_setup |
| [create_idp_saml](#gear-create_idp_saml) | Creates a SAML identity provider | common, initial_setup |
| [create_storage_share_nfs](#gear-create_storage_share_nfs) | Creates an NFS storage share on the appliance | common, initial_setup |
| [create_mapped_virtual_image](#gear-create_mapped_virtual_image) | Creates a virtual image mapped from a file share | common, create_storage_share_nfs |
| [create_role_basic_user](#gear-create_role_basic_user) | Creates a generic basic user role in the appliance | common, initial_setup |
| [create_role_no_access](#gear-create_role_no_access) | Creates a "No Access" role in the appliance | common, initial_setup |
| [create_hvm_cluster](#gear-create_hvm_cluster) | Creates and deploys an HVM cluster in the appliance | common, create_cloud_morpheus |
| [update_license](#gear-update_license) | Applies the given license to the appliance | common, initial_setup |
| [update_ui_settings](#gear-update_ui_settings) | Updates *some* of the ui settings in the administration tab in the appliance | common, initial_setup |

### Role Info
---

:gear: **common**
---

This role is strictly for the tasks which will be run in every environment, regardless of requirements.  Right now the only task gets an api bearer token for the given account credentials.

:gear: **initial_setup**
---

This role performs the initial setup of the appliance. This must be done on first installation. It will be skipped on subsequent runs.

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| morpheus_appliance_name | string | None | Naming the appliance on setup |
| morpheus_appliance_url | string | None | Setting the appliance url on setup |
| morpheus_master_tenant | string | Morpheus | Name for the master tenant |
| app_user | string | Admin | The username for the default sysad account |
| app_pass | string | 53cureP@ss1234? | The password for the default sysad account |
| morpheus_admin_email | string | no@mail.com | Email address for the default sysad account |
| morpheus_admin_firstname | string | Admin | First name for the default sysad account |
| morpheus_admin_lastname | string | Istrator | Last name for the default sysad account |
| morpheus_enable_backups | bool | false | Enable backups for the appliance? |
| morpheus_enable_monitoring | bool | false | Enable monitoring for the appliance? |
| morpheus_enable_logs | bool | false | Enable logging? | 
| morpheus_hub_mode | string | skip | Skips hub mode. Keep this default, hub will be retiring |

:gear: create_cloud_morpheus
---

This role will create a Morpheus type cloud named in the appliance and grant access to the first group created from the list of provided groups to create

**Depends On**

[common](#gear-common)
[create_groups](#gear-create_groups)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| morpheus_cloud_name | string | None | Name for the Morpheus type cloud |
| morpheus_cloud_code | string | None | Code for the Morpheus type cloud |

:gear: create_cloud_vcenter
---

This role will create a vCenter type cloud in the appliance and grant access to the first group created from the list of provided groups to create

**Depends On**

[common](#gear-common)
[create_groups](#gear-create_groups)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| vcenter_cloud_url | string | None | The vCenter url to connect to |
| vcenter_cloud_user | string | None | The admin/service account for the vCenter |
| vcenter_cloud_pass | string | None | The password for the admin/service account |
| vcenter_cloud_name | string | None | The name for the cloud in the appliance |
| vcenter_cloud_code | string | None | The code for the cloud in the appliance |
| vcenter_cloud_datacenter | string | None | Name of the vCenter datacenter to connect to |
| vcenter_cloud_cluster | string | All | The cluster to scope the cloud to | 
| vcenter_cloud_resource_group_id | string | blank | The resource group id to scope the cloud to. If cluster is scoped to All, leave the default |
| vcenter_cloud_enable_inventory | string | on | Enable inventory on the cloud |


:gear: create_groups
---

This role will create infrastructure groups from a list of names

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| morpheus_groups | list | None | List of groups to create in the appliance with name and code |

:gear: create_hvm_cluster
---

This role will create and deploy an HVM cluster in the appliance

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)
[create_cloud_morpheus](#gear-create_cloud_morpheus)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| cluster_name | string | None | Name for the cluster in the appliance |
| cluster_ssh_username | string | None | SSH sudo user for all hosts in the cluster |
| cluster_ssh_password | string | None | SSH sudo user password |
| management_interface_name | string | None | Name of the management interface on the hosts |
| compute_interface_name | string | None | Name of the compute interface on the hosts |
| compute_vlans | string | None | Range of VLAN network to create on the hosts |
| server_list | list | None | List of servers to add to the cluster with "name" and "ip" |

:gear: create_idp_ad
---

This role will create an Active Directory identity provider in the appliance

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| active_directory_server | string | None | The server url for Active Directory |
| active_directory_domain | string | None | The Active Directory domain name |
| active_directory_username | string | None | User with directory read access |
| active_directory_password | string | None | Password for AD Bind user |
| active_directory_required_group | string | None | The AD group a user must be a member of to gain access to Morpheus |
| active_directory_integration_name | string | None | Name for the IDP integration in the appliance |


:gear: create_idp_saml
---

This role will create a SAML identity provider in the appliance. This will still require configuraiton on IDP side of the equation. This just sets up the inital provider config in Morpheus. 

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)
[create_role_basic_user](#gear-create_role_basic_user) (If you want to assign the "Basic User" role to a group from the IDP)
[create_role_no_access](#gear-create_role_no_access) (If you want to assign the no access role as the default role for users)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| morpheus_identity_saml_default_role | string | None | The default role assigned to users when they log in with no other role assignment |
| morpheus_identity_saml_url | string | None | URL for the SAML identity provider |
| morpheus_identity_saml_logout_url | string | None | Logout URL forthe identiry provider |
| morpheus_identity_saml_givenNameAttribute | string | None | The given name (First Name) attribute name provided by the IDP |
| morpheus_identity_saml_surnameAttribute | string | None | The surname (Last Name) attribute name provided by the IDP |
| morpheus_identity_saml emailAttribute | string | None | The email attribute name provided by the IDP |
| morpheus_identity_saml_roleAttributeName | string | None | The role attribute name provided by the IDP |
| morpheus_identity_saml_name | string | None | The name for the IDP in the appliance |
| morpheus_identity_saml_description | string | None | A description for the IDP in the appliance |
| morpheus_identity_saml_role_mappings | list | None | A list of role mappings to apply to the IDP with "role" and "group" names | 


:gear: create_mapped_virtual_image
---

This role will create a virtual image mapped from a storage share.

**Depends On**

[create_storage_share_nfs](#gear-create_storage_share_nfs) Storage bucket must already exist before this can work

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| storage_bucket_id | string | None | The ID of the storage bucket the image resides in |
| image_name | string | None | The name for the image in the appliance |
| image_labels | list | None | List of labels to apply to the image |
| image_type | string | None | What type of image is it. (iso, qcow2, vmdk, etc...)
| image_url | string | None | The path to the folder that contains the image in the storage bucket attached to the appliance |
| cloud_init_enabled | bool | true | Is cloud init enabled on the image? |
| install_agent | bool | true | Should the morpheus agent be installed by default? |
| os_type_id | int | None | The OS type id for the image. This is ONLY required for VME Manager deployments due to an issue with a blocked API. #TODO: Find out if this is still broken |
| is_vme | bool | False | Tells the playbook if this is running against a VM Essentials manager. If it is, it skips the task of getting the OS Type ID. Tied to the previous variable. Can be removed once the API is fixed |
| image_visibility | string | Public | Should the image be Public or Private |
| auto_domain_join | bool | false | Should any instance deployed using this image automatically join a domain |
| virtio_supported | bool | true | Is this a virtio support image. True for HVM/KVM images |
| vm_tools_installed | bool | true | are vm tools installed on the image |
| force_customization | bool | false | Force guest OS custoimization. Pertinent for VMware based images |
| trial_version | bool | false | Is this a trial version of the software |
| is_sysprepped | bool | false | Is this image sysprepped. Pertinent for Windows images |


:gear: create_role_basic_user
---

This role will create a role called "Basic User" with basic permissions

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

There are no variable for you here. You get the defaults and you will like it. If you want different roles. Create them yourself.

| Name | Type | Default | Usage |
|---|---|---|---|

:gear: create_role_no_access
---

This role will create a role with no access to the appliance

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

There are no variable for you here. You get the defaults and you will like it. If you want different roles. Create them yourself.

| Name | Type | Default | Usage |
|---|---|---|---|

:gear: create_storage_share_nfs
---

This role will create an NFS backed storage share in the appliance

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| storage_bucket_name | string | None | Name for the storage bucket in the appliance |
| nfs_host | string | None | URL/IP Address for the NFS server host |
| nfs_export_folder | string | None | Path to the exported folder in the NFS server host |
| default_backup_target | bool | false | Should this be the default target for VM backups |
| default_deployment_target | bool | false | Should this be the default location for deployments |
| default_image_target | bool | false | Should this be the default image target |


:gear: update_license
---

This role will install the given license on the appliance

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| morpheus_license_key | string | None | The license you want to apply the to the appliance |


:gear: update_ui_settings
---

This role will update specific settings in the appliance. This role can be run without setting any variables and the defaults will be applied. 

**Depends On**

[common](#gear-common)
[initial_setup](#gear-initial_setup)

**Variables**

| Name | Type | Default | Usage |
|---|---|---|---|
| morpheus_browser_timeout | int | 60 | The default timeout for the browser |
| morpheus_auto_manage_checks | bool | True | Should check be created for deployed instances |
| morpheus_enable_logs | bool | True | Should logging be enabled for deployed instanced |
| morpheus_show_pricing | bool | True | Show pricing in the incatnce provision wizard |
| morpheus_reuse_sequence | bool | True | Reuse naming sequence numbers |
| morpheus_cloud_init_user | string | morph | Name for the cloud init user |
| morpheus_cloud_init_pass | string | 53cureP@ss1234? | Password for the cloud init user |
| morpheus_windows_pass | string | 53cureP@ss1234? | Password for the default Windows admin |

